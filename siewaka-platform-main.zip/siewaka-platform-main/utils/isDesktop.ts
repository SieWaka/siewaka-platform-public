export const isDesktop = () => {
  return window.innerWidth >= 1024;
};
