// imports
import { CitizenReportFormProps } from './types';
// types - interfaces

// vars

// component

export const CitizenReportForm: React.FC<CitizenReportFormProps> = ({
  handleSubmit,
}) => {
  // state

  //effects

  //handlers

  // helpers

  // jsx
  return <form onSubmit={handleSubmit} className=""></form>;
};
