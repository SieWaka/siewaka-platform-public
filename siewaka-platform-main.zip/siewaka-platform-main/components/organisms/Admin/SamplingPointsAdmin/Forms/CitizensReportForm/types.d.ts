export interface CitizenReportFormProps {
  handleSubmit: function;
}
