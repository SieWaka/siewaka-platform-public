import React from 'react';

const Divider: React.FC = () => {
  return <div className="h-px bg-divider w-full" />;
};

export default Divider;
