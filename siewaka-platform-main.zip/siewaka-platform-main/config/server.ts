export const BCRYPT_COST = 12;
