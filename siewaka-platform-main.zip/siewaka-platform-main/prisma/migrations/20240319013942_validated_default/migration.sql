-- AlterTable
ALTER TABLE "CitizenReport" ALTER COLUMN "verified" SET DEFAULT false;
