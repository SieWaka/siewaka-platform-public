-- CreateTable
CREATE TABLE "SampleAlert" (
    "id" UUID NOT NULL,

    CONSTRAINT "SampleAlert_pkey" PRIMARY KEY ("id")
);
