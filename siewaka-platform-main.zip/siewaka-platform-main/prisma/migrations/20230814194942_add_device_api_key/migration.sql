-- AlterTable
ALTER TABLE "Device" ADD COLUMN     "apiKey" VARCHAR(100);
